# Spin the Wheel for Meesho Customers

## 📦 What's Included

- `index.html` – Spin the wheel game
- `form.html` – Form page to claim prize
- `assets/winwheel.min.js` – Spin wheel JS library

## 🚀 How to Use

1. Upload files to your GitHub repo
2. Replace the Google Form link in `form.html`
3. Deploy the repo using GitHub Pages
4. Generate a QR code linking to `index.html`
5. Include QR card in your product package

## 🎁 Enjoy customer engagement + reviews!
